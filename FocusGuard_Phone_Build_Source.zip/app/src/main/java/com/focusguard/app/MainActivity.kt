package com.focusguard.app

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.accessibility.AccessibilityManager
import android.widget.*
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("focusguard", Context.MODE_PRIVATE) }
    private val selected = mutableSetOf<String>()
    private lateinit var status: TextView
    private lateinit var duration: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        selected.addAll(prefs.getStringSet("blocked_packages", emptySet()) ?: emptySet())
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 24, 28, 24)
            setBackgroundColor(0xFFF5F6FA.toInt())
        }
        val title = TextView(this).apply {
            text = "FocusGuard"
            textSize = 30f
            setTextColor(0xFF17233C.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        root.addView(TextView(this).apply {
            text = "Strict focus sessions • Block distracting apps"
            textSize = 14f; setTextColor(0xFF566176.toInt())
            setPadding(0, 4, 0, 18)
        })
        status = TextView(this).apply {
            textSize = 14f; setTextColor(0xFF26344D.toInt())
            setPadding(14, 14, 14, 14)
            setBackgroundColor(0xFFE4EAF5.toInt())
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "1. Enable Accessibility"
            textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 22, 0, 8)
        })
        root.addView(Button(this).apply {
            text = "Open Accessibility Settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(TextView(this).apply {
            text = "2. Choose apps to block"
            textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 18, 0, 4)
        })
        root.addView(TextView(this).apply {
            text = "Select installed apps below. YouTube Shorts and Instagram Reels detection is best-effort and depends on their screen labels."
            textSize = 13f; setTextColor(0xFF566176.toInt())
        })
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        val apps = getInstalledLaunchableApps()
        apps.forEach { info ->
            val cb = CheckBox(this).apply {
                text = info.loadLabel(packageManager).toString()
                isChecked = selected.contains(info.packageName)
                setOnCheckedChangeListener { _, checked ->
                    if (checked) selected.add(info.packageName) else selected.remove(info.packageName)
                    saveSelection()
                }
                setPadding(4, 6, 4, 6)
            }
            list.addView(cb)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(TextView(this).apply {
            text = "3. Session length"
            textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 14, 0, 4)
        })
        duration = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("25 minutes", "50 minutes", "90 minutes", "120 minutes", "180 minutes"))
        }
        root.addView(duration)
        root.addView(Button(this).apply {
            text = "START STRICT FOCUS"
            setOnClickListener {
                saveSelection()
                if (!isAccessibilityEnabled()) {
                    Toast.makeText(this@MainActivity, "Enable FocusGuard in Accessibility Settings first.", Toast.LENGTH_LONG).show()
                    startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                } else if (selected.isEmpty()) {
                    Toast.makeText(this@MainActivity, "Select at least one app to block.", Toast.LENGTH_LONG).show()
                } else {
                    val mins = listOf(25, 50, 90, 120, 180)[duration.selectedItemPosition]
                    prefs.edit().putLong("session_end", System.currentTimeMillis() + TimeUnit.MINUTES.toMillis(mins.toLong()))
                        .putBoolean("session_active", true).apply()
                    startActivity(Intent(this@MainActivity, SessionActivity::class.java))
                }
            }
        })
        root.addView(Button(this).apply {
            text = "Refresh status"
            setOnClickListener { refreshStatus() }
        })
        setContentView(root)
        refreshStatus()
    }

    private fun saveSelection() {
        prefs.edit().putStringSet("blocked_packages", selected.toSet()).apply()
    }

    private fun isAccessibilityEnabled(): Boolean {
        val am = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName &&
                    it.resolveInfo.serviceInfo.name == FocusAccessibilityService::class.java.name }
    }

    private fun refreshStatus() {
        val end = prefs.getLong("session_end", 0L)
        val active = prefs.getBoolean("session_active", false) && end > System.currentTimeMillis()
        status.text = if (active) "Focus session active • ${selected.size} apps selected"
                      else "No active focus session • ${selected.size} apps selected"
    }

    @Suppress("DEPRECATION")
    private fun getInstalledLaunchableApps(): List<ApplicationInfo> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
    }
}

class SessionActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("focusguard", Context.MODE_PRIVATE) }
    private lateinit var timer: TextView
    private val handler = android.os.Handler()
    private val tick = object : Runnable {
        override fun run() {
            val remaining = prefs.getLong("session_end", 0L) - System.currentTimeMillis()
            if (remaining <= 0) {
                prefs.edit().putBoolean("session_active", false).apply()
                timer.text = "Session complete. Well done!"
            } else {
                val m = TimeUnit.MILLISECONDS.toMinutes(remaining)
                val s = TimeUnit.MILLISECONDS.toSeconds(remaining) % 60
                timer.text = "Focus time remaining\n%02d:%02d".format(m, s)
                handler.postDelayed(this, 1000)
            }
        }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(30, 30, 30, 30); setBackgroundColor(0xFFF5F6FA.toInt())
        }
        timer = TextView(this).apply {
            textSize = 28f; gravity = Gravity.CENTER; setTextColor(0xFF17233C.toInt())
            typeface = Typeface.DEFAULT_BOLD
        }
        box.addView(timer)
        box.addView(TextView(this).apply {
            text = "Strict mode is active. Selected apps will be blocked until the timer ends."
            textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 20, 0, 20)
        })
        box.addView(Button(this).apply {
            text = "Return to home"
            setOnClickListener { val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME); startActivity(i) }
        })
        setContentView(box)
        handler.post(tick)
    }
    override fun onDestroy() { handler.removeCallbacks(tick); super.onDestroy() }
}
