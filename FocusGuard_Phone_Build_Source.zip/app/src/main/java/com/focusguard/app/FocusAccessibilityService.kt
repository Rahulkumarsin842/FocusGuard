package com.focusguard.app

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class FocusAccessibilityService : AccessibilityService() {
    private val prefs by lazy { getSharedPreferences("focusguard", Context.MODE_PRIVATE) }
    private var lastBlockAt = 0L
    private var lastBlockedKey = ""

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event ?: return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED &&
            event.eventType != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) return

        val now = System.currentTimeMillis()
        val end = prefs.getLong("session_end", 0L)
        val active = prefs.getBoolean("session_active", false) && now < end
        if (!active) {
            if (prefs.getBoolean("session_active", false)) prefs.edit().putBoolean("session_active", false).apply()
            return
        }

        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui") return

        val blocked = prefs.getStringSet("blocked_packages", emptySet()) ?: emptySet()
        val appBlocked = blocked.contains(pkg)
        val shortVideoBlocked = isShortVideoScreen(pkg)

        if (appBlocked || shortVideoBlocked) {
            val key = "$pkg:${if (appBlocked) "app" else "short"}"
            // Avoid repeatedly opening the blocking screen for every content event.
            if (key == lastBlockedKey && now - lastBlockAt < 1800) return
            lastBlockedKey = key
            lastBlockAt = now
            val i = Intent(this, BlockedActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("blocked_app", if (appBlocked) "This app" else "Short-form video")
            }
            startActivity(i)
        }
    }

    private fun isShortVideoScreen(pkg: String): Boolean {
        if (pkg != "com.google.android.youtube" && pkg != "com.instagram.android") return false
        val root = rootInActiveWindow ?: return false
        val terms = if (pkg == "com.google.android.youtube")
            listOf("shorts", "short video", "shorts player")
        else listOf("reels", "reel")
        return containsTerm(root, terms, 0)
    }

    private fun containsTerm(node: AccessibilityNodeInfo, terms: List<String>, depth: Int): Boolean {
        if (depth > 18) return false
        val value = buildString {
            node.text?.let { append(it).append(' ') }
            node.contentDescription?.let { append(it).append(' ') }
            node.viewIdResourceName?.let { append(it).append(' ') }
        }.lowercase()
        if (terms.any { value.contains(it) }) return true
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = containsTerm(child, terms, depth + 1)
            child.recycle()
            if (found) return true
        }
        return false
    }

    override fun onInterrupt() {}
}
