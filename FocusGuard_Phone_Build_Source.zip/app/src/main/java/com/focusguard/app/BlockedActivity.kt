package com.focusguard.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class BlockedActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("focusguard", Context.MODE_PRIVATE)
        val end = prefs.getLong("session_end", 0L)
        val remaining = ((end - System.currentTimeMillis()).coerceAtLeast(0L) / 60000L)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32); setBackgroundColor(0xFF17233C.toInt())
        }
        root.addView(TextView(this).apply {
            text = "FOCUSGUARD"
            textSize = 15f; gravity = Gravity.CENTER; setTextColor(0xFFB8C8E8.toInt())
        })
        root.addView(TextView(this).apply {
            text = "Stay focused."
            textSize = 32f; gravity = Gravity.CENTER; setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 18, 0, 12)
        })
        root.addView(TextView(this).apply {
            text = "${intent.getStringExtra("blocked_app") ?: "This content"} is blocked during your focus session.\n\nAbout $remaining minutes remaining."
            textSize = 17f; gravity = Gravity.CENTER; setTextColor(0xFFE0E7F3.toInt())
        })
        root.addView(Button(this).apply {
            text = "Back to safety"
            setOnClickListener {
                val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(home)
                finish()
            }
        })
        setContentView(root)
    }

    @Deprecated("Deprecated in Android")
    override fun onBackPressed() {
        val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        home.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(home)
        finish()
    }
}
