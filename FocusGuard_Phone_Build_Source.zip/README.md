# FocusGuard — Android starter project

FocusGuard is a Kotlin Android Studio project for a local, sideloaded app blocker.

## What is included
- Select installed launchable apps to block during a focus session.
- Focus durations: 25, 50, 90, 120, and 180 minutes.
- Strict session behavior: the session cannot be ended from the FocusGuard UI; selected apps remain blocked until the timer expires.
- Best-effort YouTube Shorts / Instagram Reels detection using Accessibility node text and descriptions.

## Build steps
1. Install **Android Studio** (stable version) on a Windows, Mac, or Linux computer.
2. Extract `FocusGuard.zip`.
3. In Android Studio choose **Open** and select the extracted `FocusGuard` folder.
4. Allow Android Studio to install the required Android Gradle Plugin and SDK 35 components.
5. Connect an Android phone with USB debugging enabled, or create an emulator.
6. Press **Run**. The app will install on the phone.
7. Open FocusGuard and tap **Open Accessibility Settings**.
8. Find **FocusGuard app blocking** under Installed/Downloaded apps and enable it.
9. Return to FocusGuard, select apps such as YouTube and Instagram, choose a duration, then tap **START STRICT FOCUS**.

## Important limitations and safety
- This is a functional starter project, not a tamper-proof commercial blocker.
- Android/OEM battery management can stop accessibility services; allow FocusGuard to run in the background if your phone offers that setting.
- App blocking depends on the Accessibility Service remaining enabled. A user can still disable it from Android Settings, reboot into safe mode, uninstall the app, or use another device. Android does not let an ordinary third-party app guarantee unbypassable blocking.
- Shorts/Reels detection is heuristic. App updates, localization, hidden labels, and UI changes can make it miss content or occasionally block the wrong screen. It is not a guaranteed way to distinguish every short video from normal content.
- The project uses `QUERY_ALL_PACKAGES` to show installed apps. This is appropriate for a personal sideloaded build; Google Play has strict policy limits on broad app visibility and Accessibility API use.
- No network access or analytics are included. The app stores its settings locally in SharedPreferences.
- Strict mode deliberately has no in-app early-stop button. Keep a safe way to reach emergency calling, maps, accessibility tools, and essential apps; do not block those apps.
- Before relying on it, test with short sessions and non-essential apps only.

## Troubleshooting
- If apps are not listed, check that they have a launcher icon and restart FocusGuard.
- If blocking does not trigger, verify Accessibility is enabled and the service is still running.
- If the service is killed by the phone, disable battery optimization for FocusGuard in Android settings where available.
- If Gradle sync fails, update Android Studio and install the SDK version requested by the build output.

## Package
`com.focusguard.app`


## Build without a computer (GitHub Actions)
1. On your phone, sign in to GitHub in Chrome.
2. Create a new repository named `FocusGuard` (public is simplest for free Actions use; do not upload private secrets).
3. Upload the contents of this project, preserving folder structure, to the repository's `main` branch. Include the `.github/workflows/build.yml` file.
4. Open the repository's **Actions** tab and select **Build FocusGuard APK**.
5. Tap **Run workflow** if it has not started automatically.
6. Wait for the workflow to finish successfully, open its run, and download the `FocusGuard-debug-apk` artifact.
7. Extract the downloaded artifact ZIP on your phone and tap `app-debug.apk` to install it. Allow Chrome or your file manager to install unknown apps if Android asks.

The cloud workflow compiles the APK; it does not run the app or test Accessibility behavior. You must install and test it on your phone.
